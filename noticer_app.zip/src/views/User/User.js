import React, {Component} from 'react';

class User extends Component
{
    render()
    {
        return(
            <div>
                <p>user function</p>
            </div>
        );
    }
}

export default User;