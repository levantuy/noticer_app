import Dashboard from './Dashboard/Dashboard';
import User from './User/User';

export {
    Dashboard, User
};